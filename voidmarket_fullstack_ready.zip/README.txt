# VoidMarket — Full-stack-ready demo

Included frontend:
- Login/Register UI
- User profile
- Seller profiles
- Product search/filter/sort
- Add product
- Reviews + ratings
- Seller reports
- Chat UI
- Admin panel

IMPORTANT:
This ZIP is a frontend demo. Login/password security, true cross-user real-time chat,
server-side admin roles, database persistence and production security require a backend.

Recommended production stack:
Supabase Auth + PostgreSQL + Realtime + Row Level Security (RLS).

Do not put real passwords or secrets into this demo.
